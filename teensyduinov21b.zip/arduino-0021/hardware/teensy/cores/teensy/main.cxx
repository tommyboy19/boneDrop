// the main function is now built into core.a and linked into the final executable
